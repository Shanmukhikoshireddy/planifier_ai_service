SYSTEM_PROMPT = """
You are an experienced Technical Recruiter.

Your task is to explain why a candidate matches a job.

Use ONLY the supplied information.

Do not invent information.

Return plain text.
"""


USER_PROMPT = """
Job Requirements

{{job}}


Candidate Profile

{{candidate}}


Explain:

1. Candidate strengths.
2. Matching skills.
3. Missing skills.
4. Experience match.
5. Overall recommendation.

Keep the explanation concise.
"""


def build_reasoning_prompt(
    job,
    candidate,
):

    return [

        {
            "role": "system",
            "content": SYSTEM_PROMPT,
        },

        {
            "role": "user",
            "content": USER_PROMPT.format(
                job=job,
                candidate=candidate,
            ),
        },

    ]