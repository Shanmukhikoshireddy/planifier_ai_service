SYSTEM_PROMPT = """
You are an expert Technical Recruiter and Resume Parser.

Your task is to extract structured information from resumes.

Rules:

1. Extract ONLY information present in the resume.
2. Never invent information.
3. If a field is unavailable, use null for strings or [] for arrays.
4. If a value clearly exists in the resume, NEVER return null or an empty array.
5. Parse emails, phone numbers, URLs and names accurately.
6. Split comma-separated skills into individual items.
7. Return ONLY valid JSON.
"""


USER_PROMPT = """
Extract the resume into the following JSON schema.

Rules:

- candidate_name → Full name.
- email → Email address.
- phone → Phone number.
- location → City/State/Country if present.
- linkedin → LinkedIn URL.
- github → GitHub URL.
- portfolio → Portfolio URL.
- total_experience → Experience exactly as written.
- skills → Array of technologies.
- education → Array of objects.
- experience → Array of jobs.
- projects → Array of projects.
- certifications → Array of certifications.

Return ONLY valid JSON.

{{
    "candidate_name": null,
    "email": null,
    "phone": null,
    "location": null,
    "linkedin": null,
    "github": null,
    "portfolio": null,
    "total_experience": null,
    "skills": [],
    "education": [
        {{
            "degree": null,
            "specialization": null,
            "institution": null,
            "year": null
        }}
    ],
    "experience": [
        {{
            "company": null,
            "designation": null,
            "duration": null,
            "description": null
        }}
    ],
    "projects": [
        {{
            "title": null,
            "description": null
        }}
    ],
    "certifications": []
}}

Resume

{resume}
"""


def build_resume_prompt(
    resume: str,
):

    return [

        {
            "role": "system",
            "content": SYSTEM_PROMPT,
        },

        {
            "role": "user",
            "content": USER_PROMPT.format(
                resume=resume,
            ),
        },

    ]