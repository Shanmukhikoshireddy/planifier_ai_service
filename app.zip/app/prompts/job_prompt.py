SYSTEM_PROMPT = """
You are an experienced Technical Recruiter.

Your task is to analyze a Job Description and extract structured hiring requirements.

Return ONLY valid JSON.

Do not explain anything.
"""


USER_PROMPT = """
Extract the following information from the Job Description.

Return ONLY valid JSON.

{{
    "title": "",
    "experience": "",
    "education": "",
    "skills": [],
    "responsibilities": [],
    "qualifications": [],
    "nice_to_have": []
}}

Job Description

{{job_description}}
"""


def build_job_prompt(
    job_description: str,
):

    return [

        {
            "role": "system",
            "content": SYSTEM_PROMPT,
        },

        {
            "role": "user",
            "content": USER_PROMPT.format(
                job_description=job_description,
            ),
        },

    ]