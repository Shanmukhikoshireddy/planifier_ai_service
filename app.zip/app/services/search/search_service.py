from app.config.logging import logger

from app.repository.job_repository import JobRepository
from app.repository.search_repository import SearchRepository
from app.repository.embedding_repository import EmbeddingRepository
from app.repository.profile_repository import ProfileRepository

from app.services.shared.openai_service import OpenAIService

from app.services.ingestion.embedding_service import EmbeddingService

from app.services.search.cache_service import CacheService
from app.services.search.reranker_service import RerankerService
from app.services.search.scoring_service import ScoringService

from app.prompts.job_prompt import build_job_prompt
from app.prompts.reasoning_prompt import build_reasoning_prompt


class SearchService:

    """
    Complete Candidate Search Workflow.
    """

    def __init__(self):

        self.job_repository = JobRepository()

        self.search_repository = SearchRepository()

        self.embedding_repository = EmbeddingRepository()

        self.profile_repository = ProfileRepository()

        self.openai_service = OpenAIService()

        self.embedding_service = EmbeddingService()

        self.cache_service = CacheService()

        self.reranker_service = RerankerService()

        self.scoring_service = ScoringService()


    # =====================================================
    # Search Candidates
    # =====================================================

    def search(
        self,
        department: str,
        job_description: str,
        search_period: str,
        page: int,
        page_size: int,
    ):

        logger.info(

            "Starting Candidate Search."

        )

        # --------------------------------------

        prompt = build_job_prompt(

            job_description

        )

        job = self.openai_service.generate_json(

            prompt

        )

        logger.info(

            "Job Parsed Successfully."

        )

        # Remaining implementation
        # Part-2

        return self.process_job(
            job=job,
            department=department,
            search_period=search_period,
            page=page,
            page_size=page_size,
            raw_job_description=job_description,
        )
    
        # =====================================================
    # Build Job Text
    # =====================================================

    def build_job_embedding_text(

        self,

        job,

    ):

            return f"""

    Title

    {job.get('title','')}

    Experience

    {job.get('experience','')}

    Education

    {job.get('education','')}

    Skills

    {' '.join(job.get('skills',[]))}

    Responsibilities

    {' '.join(job.get('responsibilities',[]))}

    Qualifications

    {' '.join(job.get('qualifications',[]))}

    Nice To Have

    {' '.join(job.get('nice_to_have',[]))}

    """.strip()




    # =====================================================
    # Process Job
    # =====================================================

    def process_job(
        self,
        job,
        department,
        search_period,
        page,
        page_size,
        raw_job_description,
    ):
        # --------------------------------------------
        # Build Job Embedding Text
        # --------------------------------------------

        job_text = self.build_job_embedding_text(

            job

        )

        # --------------------------------------------
        # Generate Job Embedding
        # --------------------------------------------

        job_embedding = self.embedding_service.generate_embedding(

            job_text

        )

        logger.info(

            "Job embedding generated."

        )

        # --------------------------------------------
        # Check Cache
        # --------------------------------------------

        cached_job = self.cache_service.find_similar_job(

            embedding=job_embedding,

            department=department,


        )

        if cached_job:

            logger.info("Cache Hit.")

            results = self.search_repository.get_search_results(

                str(cached_job["_id"])

            )

            start = (page - 1) * page_size

            end = start + page_size

            return {

                "job_id": str(cached_job["_id"]),

                "page": page,

                "page_size": page_size,

                "total_candidates": len(results),

                "total_pages": (

                    len(results) + page_size - 1

                ) // page_size,

                "results": results[start:end],

            }

        logger.info(

            "Cache Miss."

        )

        # --------------------------------------------
        # Save Job
        # --------------------------------------------

        job_id = self.job_repository.create_job(

            job=job,

            embedding=job_embedding,

            department=department,

            search_period=search_period,

        )

        logger.info(

            f"Job Created : {job_id}"

        )

        return self.vector_search(

            job_id=job_id,

            job=job,

            job_text=job_text,

            job_embedding=job_embedding,

            department=department,

            search_period=search_period,

            page=page,

            page_size=page_size,

            raw_job_description=raw_job_description,

        )

            # =====================================================
    # Vector Search
    # =====================================================

    def vector_search(

        self,

        job_id: str,

        job,

        job_text: str,

        job_embedding: list,

        department: str,

        search_period: str,

        page: int,

        page_size: int,

        raw_job_description: str,

    ):

        logger.info(

            "Running Atlas Vector Search..."

        )

        vector_results = self.embedding_repository.search_similar_embeddings(

            embedding=job_embedding,

            department=department,

            search_period=search_period,

        )

        logger.info(

            f"Retrieved {len(vector_results)} candidates."

        )

        candidates = []

        for result in vector_results:

            profile = self.profile_repository.get_profile(

                result["resume_id"]

            )

            if profile is None:

                continue

            profile["semantic_score"] = result.get(

                "embedding_score",

                0,

            )

            candidates.append(

                profile

            )

        logger.info(

            f"Loaded {len(candidates)} candidate profiles."

        )

        return self.rerank_candidates(

            job_id=job_id,

            job=job,

            job_text=job_text,

            candidates=candidates,

            page=page,

            page_size=page_size,

            raw_job_description=raw_job_description,

        )
    

            # =====================================================
    # Rerank Candidates
    # =====================================================

    def rerank_candidates(

        self,

        job_id: str,

        job,

        job_text: str,

        candidates: list,

        page: int,

        page_size: int,

        raw_job_description: str,

    ):

        logger.info(

            "Running Cross Encoder Reranker..."

        )

        for candidate in candidates:

            candidate["resume_text"] = f"""

Candidate

{candidate.get('candidate_name', '')}

Experience

{candidate.get('total_experience', '')}

Skills

{' '.join(candidate.get('skills', []))}

Projects

{
chr(10).join(
    [
        p.get("description", "")
        for p in candidate.get("projects", [])
    ]
)
}

"""

        # --------------------------------------------
        # Rerank ALL candidates
        # --------------------------------------------

        candidates = self.reranker_service.rerank_candidates(

            job_text,

            candidates,

        )

        logger.info(

            f"Reranked {len(candidates)} candidates."

        )

        return self.score_candidates(

            job_id=job_id,

            job=job,

            candidates=candidates,

            page=page,

            page_size=page_size,

            raw_job_description=raw_job_description,

        )
        # =====================================================
    # Score Candidates
    # =====================================================

    # =====================================================
    # Score Candidates
    # =====================================================

    def score_candidates(

        self,

        job_id: str,

        job,

        candidates: list,

        page: int,

        page_size: int,

        raw_job_description: str,

    ):

        logger.info("Calculating ATS Scores...")

        required_skills = [

            skill.lower()

            for skill in job.get("skills", [])

        ]

        scored_candidates = []

        for candidate in candidates:

            # --------------------------------------------
            # Candidate Skills
            # --------------------------------------------

            candidate_skills = [

                skill.lower()

                for skill in candidate.get(

                    "skills",

                    []

                )

            ]

            matched_skills = [

                skill

                for skill in candidate_skills

                if skill in required_skills

            ]

            missing_skills = [

                skill

                for skill in required_skills

                if skill not in candidate_skills

            ]

            if required_skills:

                skill_match_percentage = round(

                    (

                        len(matched_skills)

                        /

                        len(required_skills)

                    )

                    * 100,

                    2,

                )

            else:

                skill_match_percentage = 100

            # --------------------------------------------
            # Experience
            # --------------------------------------------

            try:

                candidate_years = float(

                    candidate.get(

                        "total_experience",

                        0,

                    )

                    or 0

                )

            except Exception:

                candidate_years = 0

            required_years = self.scoring_service.extract_years(

                job.get(

                    "experience",

                    "",

                )

            )

            # --------------------------------------------
            # Education
            # --------------------------------------------

            required_education = job.get(

                "education",

                "",

            ).lower()

            candidate_education = " ".join(

                [

                    e.get(

                        "degree",

                        "",

                    )

                    for e in candidate.get(

                        "education",

                        [],

                    )

                ]

            ).lower()

            education_match = (

                required_education in candidate_education

                if required_education

                else True

            )

            # --------------------------------------------
            # Certifications
            # --------------------------------------------

            required_certifications = set(

                [

                    c.lower()

                    for c in job.get(

                        "certifications",

                        [],

                    )

                ]

            )

            candidate_certifications = set(

                [

                    c.lower()

                    for c in candidate.get(

                        "certifications",

                        [],

                    )

                ]

            )

            certification_match = bool(

                required_certifications.intersection(

                    candidate_certifications

                )

            )

            # --------------------------------------------
            # Final Score
            # --------------------------------------------

            final_score = self.scoring_service.final_score(

                similarity_score=candidate.get(

                    "semantic_score",

                    0,

                ),

                matched_skills=matched_skills,

                required_skills=required_skills,

                candidate_years=candidate_years,

                required_years=required_years,

                education_match=education_match,

                certification_match=certification_match,

            )

            candidate["matched_skills"] = matched_skills

            candidate["missing_skills"] = missing_skills

            candidate["skill_match_percentage"] = skill_match_percentage

            candidate["final_score"] = final_score

            scored_candidates.append(

                candidate

            )

        # --------------------------------------------
        # Sort by Final Score
        # --------------------------------------------

        scored_candidates.sort(

            key=lambda x: x["final_score"],

            reverse=True,

        )

        total_candidates = len(

            scored_candidates

        )

        total_pages = (

            total_candidates + page_size - 1

        ) // page_size

        # --------------------------------------------
        # Generate Reasoning
        # --------------------------------------------

        return self.generate_reasoning(

            job_id=job_id,

            job=job,

            candidates=scored_candidates,

            total_candidates=total_candidates,

            total_pages=total_pages,

            page=page,

            page_size=page_size,

            raw_job_description=raw_job_description,

        )




    # =====================================================
    # Generate Candidate Reasoning
    # =====================================================

    def generate_reasoning(

        self,

        job_id: str,

        job,

        candidates: list,

        total_candidates: int,

        total_pages: int,

        page: int,

        page_size: int,

        raw_job_description: str,

    ):

        logger.info(

            "Generating AI Reasoning..."

        )
        for candidate in candidates:

            candidate["reasoning"] = None


        self.search_repository.save_search_results(

            job_id,

            candidates,

        )

        self.job_repository.update_result_count(

            job_id,

            total_candidates,

        )

        self.job_repository.update_status(

            job_id,

            "COMPLETED",

        )

        logger.info(

            "Search Completed."

        )
        start = (page - 1) * page_size

        end = start + page_size

        paginated_candidates = candidates[start:end]

        return {

            "job_id": job_id,

            "page": page,

            "page_size": page_size,

            "total_candidates": total_candidates,

            "total_pages": total_pages,

            "results": paginated_candidates,

        }



    # =====================================================
    # Candidate Reasoning
    # =====================================================

    def get_candidate_reasoning(

    self,

    job_id: str,

    resume_id: str,

    ):

        # --------------------------------------
        # Check Cached Reasoning
        # --------------------------------------

        reasoning = self.search_repository.get_reasoning(

            job_id,

            resume_id,

        )

        if reasoning and reasoning.get(

            "reasoning_generated"

        ):

            return {

                "resume_id": resume_id,

                "reasoning": reasoning["reasoning"],

                "cached": True,

            }

        # --------------------------------------
        # Load Candidate
        # --------------------------------------

        candidate = self.search_repository.get_candidate(

            job_id,

            resume_id,

        )

        if candidate is None:

            return {

                "message": "Candidate not found."

            }

        # --------------------------------------
        # Load Job
        # --------------------------------------

        job = self.job_repository.get_job(

            job_id,

        )

        if job is None:

            return {

                "message": "Job not found."

            }

        # --------------------------------------
        # Generate AI Reasoning
        # --------------------------------------

        prompt = build_reasoning_prompt(

            job,

            candidate,

        )

        reasoning_text = self.openai_service.generate(

            prompt

        )

        # --------------------------------------
        # Save Reasoning
        # --------------------------------------

        self.search_repository.save_reasoning(

            job_id,

            resume_id,

            reasoning_text,

        )

        return {

            "resume_id": resume_id,

            "reasoning": reasoning_text,

            "cached": False,

        }