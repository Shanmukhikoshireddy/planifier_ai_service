import time

from app.config.logging import logger
from app.config.settings import settings

from app.repository.metadata_repository import MetadataRepository
from app.repository.minio_repository import MinioRepository

from app.workers.resume_processor import ResumeProcessor


class MinioScheduler:
    """
    Periodically scans the MinIO bucket for new resumes.

    Any resume that has not been processed will
    automatically enter the Resume Processing Pipeline.
    """

    def __init__(self):

        self.minio_repository = MinioRepository()

        self.metadata_repository = MetadataRepository()

        self.resume_processor = ResumeProcessor()

        self.interval = settings.SCHEDULER_INTERVAL

    # =====================================================
    # Run Scheduler
    # =====================================================

    def run(self):

        logger.info("=" * 80)
        logger.info("MINIO SCHEDULER STARTED")
        logger.info("=" * 80)

        while True:

            try:

                self.scan_bucket()

            except Exception as e:

                logger.exception(e)

            time.sleep(
                self.interval,
            )

    # =====================================================
    # Scan Bucket
    # =====================================================

    def scan_bucket(self):

        logger.info(
            "Scanning MinIO bucket..."
        )

        objects = self.minio_repository.list_objects()

        for obj in objects:

            object_path = obj.object_name

            # Skip folders

            if object_path.endswith("/"):

                continue

            # Already processed?

            if self.metadata_repository.is_processed(
                object_path,
            ):

                logger.info(
                    f"Already Processed : {object_path}"
                )

                continue

            logger.info(
                f"New Resume Found : {object_path}"
            )

            self.process_resume(
                object_path,
            )

    # =====================================================
    # Process Resume
    # =====================================================

    def process_resume(
        self,
        object_path: str,
    ):

        try:

            logger.info("=" * 80)
            logger.info(
                f"Processing : {object_path}"
            )
            logger.info("=" * 80)

            self.metadata_repository.mark_processing(object_path,)

            file_hash = self.resume_processor.process_resume(
                object_path=object_path,
            )

            self.metadata_repository.save_metadata(

                object_path=object_path,

                file_hash=file_hash,

                status="SUCCESS",

            )

            logger.info(
                f"Completed : {object_path}"
            )

        except Exception as e:

            logger.exception(e)

            self.metadata_repository.save_metadata(

                object_path=object_path,

                file_hash="",

                status="FAILED",

            )